package org.bingetest.daobinge;

import org.bingetest.modele.EvalSerie;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EvalSerieDao extends JpaRepository<EvalSerie, Integer>{

}
